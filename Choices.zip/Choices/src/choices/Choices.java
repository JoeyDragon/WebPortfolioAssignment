// Joey Mahan
// 2317 - Java Programming
// 2/23/2020

package choices;

import java.util.Scanner;

//Handle user input
public class Choices
{

    //Variables
    private int quarters;
    private int dimes;
    private int nickels;
    private int pennies;
    private int weekDay;

    //Initialize variables
    public void Choices()
    {
        quarters = 0;
        dimes = 0;
        nickels = 0;
        pennies = 0;
        weekDay = 0;
    }

    //Set variables equal to a new number
    public void setQuarters (int cents)
    {
        quarters = cents;
    }
    public void setDimes (int cents)
    {
        dimes = cents;
    }
    public void setNickels (int cents)
    {
        nickels = cents;
    }
    public void setPennies (int cents)
    {
        pennies = cents;
    }
    public void setWeekDay (int day)
    {
        weekDay = day;
    }
    
    //Get variable values
    public int getQuarters ()
    {
        return quarters;
    }
    public int getDimes ()
    {
        return dimes;
    }
    public int getNickels ()
    {
        return nickels;
    }
    public int getPennies ()
    {
        return pennies;
    }
    public int getWeekDay ()
    {
        return weekDay;
    }

    //Convert user input (int) into coin amounts
    public void convertMoney()
    {
        Scanner in = new Scanner(System.in);
        int cents = 0;

        //Get user input
        System.out.println("Welcome to the Change Calculator");
        System.out.print("Enter the number of cents (0-99): ");
        cents = in.nextInt();
        if (cents < 0 || cents > 99) {                                          //If the input is less than 0 or greater than 99, tell user input is invalid
            System.out.println(cents + " amount invalid.");
            System.out.println("Value must be between 0 and 99.");
            System.out.println("");
            return;
        }

        //Find coin amounts
        setQuarters(cents / 25);                                                //Find number of quarters
        cents = cents % 25;                                                     //Find leftover change
        setDimes(cents / 10);                                                   //Find number of dimes
        cents = cents % 10;                                                     //Find leftover change
        setNickels(cents / 5);                                                  //Find number of Nickels
        cents = cents % 5;                                                      //Find leftover change
        setPennies(cents);                                                      //Find number of pennies

        //Display coin amounts
        System.out.println("");
        System.out.println("Quarters: " + getQuarters());
        System.out.println("Dimes: " + getDimes());
        System.out.println("Nickles: " + getNickels());
        System.out.println("Pennies: " + getPennies());
        System.out.println("");
    }

    //Allow user to select a day of the week based on input (int)
    public void selectDay()
    {
        Scanner in = new Scanner(System.in);

        //Get user input
        System.out.println("Welcome to the Day Selector");
        System.out.print("Enter a number for the day (1-7): ");
        setWeekDay(in.nextInt());

        //Select day based on input
        switch (getWeekDay()) {
            case 1:
                System.out.println("Sunday: weekend");
                break;
            case 2:
                System.out.println("Monday: weekday");
                break;
            case 3:
                System.out.println("Tuesday: weekday");
                break;
            case 4:
                System.out.println("Wednesday: weekday");
                break;
            case 5:
                System.out.println("Thursday: weekday");
                break;
            case 6:
                System.out.println("Friday: weekday");
                break;
            case 7:
                System.out.println("Saturday: weekend");
                break;
            default:                                                            //If input is not a digit between 1-7, tell user that input is invalid
                System.out.println("Invalid day");
        }

    }

    public static void main(String[] args)
    {
        //Variables and new object instances
        String firstName;
        String lastName;
        int input;
        Scanner in = new Scanner(System.in);
        Choices Obj = new Choices();

        //Ask for user name and greet user
        System.out.print("Enter your first name: ");
        firstName = in.nextLine();
        System.out.print("Enter your last name : ");
        lastName = in.nextLine();
        System.out.println("Hello, " + firstName + " " + lastName);
        System.out.println("");

        //Give user options for program function
        System.out.println("Press 1 - Calculate coins for change");
        System.out.println("Press 2 - Determine day of the week");
        System.out.println("Press 3 - Both");
        
        //Get user input (int)
        input = in.nextInt();

        //Call methods based on input
        switch(input) {
            case 1:
                Obj.convertMoney();
                break;
            case 2:
                Obj.selectDay();
                break;
            case 3:
                Obj.convertMoney();
                Obj.selectDay();
                break;
            default:
                System.out.println(input + "is invalid");
        }
        System.out.println("");
        System.out.println("GoodBye");
    }

}