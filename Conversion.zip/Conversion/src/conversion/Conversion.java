//Student Name: Joey Mahan
//Course: 2317 - Java Programming
//Date: 2/13/2020

package conversion;

import java.util.Scanner;
import java.util.*;

//Convert user input
public class Conversion
{
    //Variables
    private static final long FUTURE_YEAR = 2050;
    private String name;
    private long year;
    private double height;
    private double weight;

    //Blank constructor
    public Conversion()
    {
        this.name = "";
        this.height = 0.0;
        this.weight = 0.0;
        this.year = 0;
    }

    //Constructor
    public Conversion(String name, long year, double height, double weight)
    {
        this.name = name;
        this.year = year;
        this.height = height;
        this.weight = weight;
    }

    //Set variable values
    void setName(String name) {this.name = name;}
    void setYear(long year) {this.year = year;}
    void setHeight(double height) {this.height = height;}
    void setWeight(double weight) {this.weight = weight;}

    //Get variable values
    String getName( ) {return this.name;}
    long getYear( ) {return this.year;}
    double getHeight( ) {return this.height;}
    double getWeight( ) {return this.weight;}

    static long getFutureYear(){ return FUTURE_YEAR;}

    //Get current year
    long computeAge()
    {
        GregorianCalendar now = new GregorianCalendar();
        return (now.get(GregorianCalendar.YEAR) - this.year ) ;
    }

    //Convert values
    double convertHeight() { return (this.height * 2.54); }                     //Converts inches to centimeters
    double convertWeight() { return (this.weight / 2.205); }                    //Converts pounds to kilograms

    //Find future age
    long computeAge(long year){ return FUTURE_YEAR - year; }

    public static void main(String[] args)
    {

        //Variables
        String userName="";
        long Year =0;
        double Height =0.0;
        double Weight =0.0;

        Scanner keyboard = new Scanner(System.in);

        //Ask user for input
        System.out.print("What is your name? : ");
        userName = keyboard.nextLine();
        System.out.print("Enter your 4 digit birth year : ");
        Year = keyboard.nextLong();
        System.out.print("Enter your height in inches : ");
        Height = keyboard.nextDouble();
        System.out.print("Enter your weight in pounds : ");
        Weight = keyboard.nextDouble();

        //Make conversions
        Conversion obj = new Conversion(userName, Year, Height, Weight);

        //Display new values
        System.out.println(obj.getName() + ", you are " + obj.computeAge()
        + " years old, " + obj.convertHeight()
        + " cm tall, and weigh " + obj.convertWeight()
        + " kilograms." );

        System.out.println(obj.getName() + ", you will be " + obj.computeAge(Year)
        + " by the year " + getFutureYear() + "." );

    }
}